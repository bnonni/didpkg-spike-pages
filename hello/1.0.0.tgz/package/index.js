module.exports = 'hello 1.0.0 from didpkg';
